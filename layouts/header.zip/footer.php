
</div>
</div>

</div>
<!-- /.row -->
</div>
<!-- /.container-fluid -->
</div>
<!-- /#page-wrapper -->

</div>

<!-- jQuery -->
<script src="vendor/jquery/jquery.min.js"></script>

<!-- Bootstrap Core JavaScript -->
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!-- bootbox -->
<script src="js/bootbox.min.js"></script>
<script src="js/jquery.json.min.js"></script>
<!--datetimepicker-->
<script src="js/datetimepicker/bootstrap-datetimepicker.min.js"></script>
<!-- Metis Menu Plugin JavaScript -->
<script src="vendor/metisMenu/metisMenu.min.js"></script>
<!-- datatable -->
<script src="js/datatable/jquery.dataTables.min.js"></script>
<!-- Custom Theme JavaScript -->
<script src="dist/js/sb-admin-2.js"></script>
<!-- toast -->
<script src="js/jquery.toast.js"></script>
<script src="js/pace.min.js"></script>

